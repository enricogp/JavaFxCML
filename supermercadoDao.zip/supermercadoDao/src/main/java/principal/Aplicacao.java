package principal;
import java.util.List;
import java.util.Scanner;

import dao.ProdutoDAO;
import modelo.Produto;

public class Aplicacao 
{
	
	public static void main(String[] args) 
	{
		boolean repetir = true;
		
		while(repetir == true) 
		{
			Scanner entrada = new Scanner(System.in);
			
			ProdutoDAO dao = new ProdutoDAO();
			
			System.out.println("-Digite 1 para inserir produtos, 2 para editar, 3 para remover,  4 para listagem, 5 para pesquisar, ou 6 para sair-");
			String escolha = entrada.nextLine();
			
			if (escolha.contentEquals("1")) 
			{
				System.out.println("\nInsira o nome do produto:");
				String nome = entrada.nextLine();
				System.out.println("\nInsira a descri��o do produto:");
				String descricao = entrada.nextLine();
				System.out.println("\nInsira o pre�o do produto:");
				float preco = Float.parseFloat(entrada.nextLine());
				Produto prod = new Produto();
				prod.setNome(nome);
				prod.setDescricao(descricao);
				prod.setPreco(preco);
				
				dao.inserir(prod);
			}
			else if (escolha.contentEquals("2")) 
			{
				System.out.println("\nInsira o ID do produto que deseja editar:");
				int id = Integer.parseInt(entrada.nextLine());
				
				Produto prod = dao.getPeloID(id);
				System.out.println("Digite o novo nome:");
				String novoNome = entrada.nextLine();
				prod.setNome(novoNome);
				System.out.println("Digite a nova descri��o nome:");
				String novaDescricao = entrada.nextLine();
				prod.setNome(novoNome);
				System.out.println("Digite o novo preco:");
				float novoPreco = Float.parseFloat(entrada.nextLine());
				prod.setNome(novoNome);
				prod.setDescricao(novaDescricao);
				prod.setPreco(novoPreco);
				
				dao.alterar(prod);
			}
			else if (escolha.contentEquals("3")) 
			{
				System.out.println("\nInsira o ID do produto que deseja remover:");
				int id = Integer.parseInt(entrada.nextLine());
				Produto prod = dao.getPeloID(id);
				dao.deletar(prod);
			}
			else if (escolha.contentEquals("4")) 
			{
				System.out.println("\nDigite 1 para ordenar por ID, digite 2 para ordenar por nome");
				String escolhaOrd = entrada.nextLine();
				List<Produto> lista = null;
				
				if (escolhaOrd.contentEquals("2")) 
				{
					lista = dao.getTodosOrdNome();
				}
				
				else 
				{
					lista = dao.getTodos();
				}
				
				System.out.println(relatorio(lista));
				
				System.out.println("\nAperte Enter para continuar");
				
				String pausaLista = entrada.nextLine();
			}
			else if (escolha.contentEquals("5")) 
			{
				System.out.println("\nDigite 1 para pesquisar por ID, digite 2 para pesquisar por nome");
				String escolhaPesq = entrada.nextLine();
				if (escolhaPesq.contentEquals("2")) 
				{
					System.out.println("\nDigite o nome que deseja pesquisar");
					String escolhaPesq2 = entrada.nextLine();
					Produto prod = dao.getPorNome(escolhaPesq2);
					System.out.println(relatorioEspecifico(prod));
					String pausaPesq = entrada.nextLine();
					
				}
				else 
				{
					System.out.println("\nDigite o ID que deseja pesquisar");
					int escolhaPesq2 = Integer.parseInt(entrada.nextLine());
					Produto prod = dao.getPeloID(escolhaPesq2);
					System.out.println(relatorioEspecifico(prod));
					String pausaPesq = entrada.nextLine();	
				}
				
				System.out.println("\nAperte Enter para continuar");
			}
			else 
			{
				repetir = false;
				System.out.println("FIM");
			}
		}
		
	}
	
	public static String relatorio (List<Produto> lista) 
	{
		String msg = "\n-Lista de produtos-\n";
		
		for (Produto prod :lista) 
		{
			msg += "\nId: " + prod.getId() + "\nNome: " + prod.getNome() + "\nDescricao: " + prod.getDescricao() + "\nPre�o: " + prod.getPreco() + "\n";
		}
		
		return msg;
	}
	
	public static String relatorioEspecifico (Produto prod) 
	{
		String msg = "\nId: " + prod.getId() + "\nNome: " + prod.getNome() + "\nDescricao: " + prod.getDescricao() + "\nPre�o: " + prod.getPreco() + "\n";
		
		return msg;
	}

}
