package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import modelo.Produto;
public class ProdutoDAO 
{
	
	String CONSULTA_TODOS = "produto.todos";
	String CONSULTA_ORDNOME = "produto.ordNome";
	String CONSULTA_PORNOME = "produto.porNome";
	
	private EntityManagerFactory factory;
	private EntityManager em;
	
	public ProdutoDAO() {
		super();
		if (factory == null) 
		{
			this.inicializa();
		}
	}
	
	public void inicializa() 
	{
		factory = Persistence.createEntityManagerFactory("dbProduto");
		em = factory.createEntityManager();
	}
	
	public boolean inserir (Produto obj) 
	{
		try 
		{
			em.getTransaction().begin();
			em.persist(obj);
			em.getTransaction().commit();
			return true;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean deletar (Produto obj) 
	{
		try 
		{
			em.getTransaction().begin();
			em.remove(obj);
			em.getTransaction().commit();
			return true;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean alterar(Produto obj) {
		try {
			em.getTransaction().begin();
			em.merge(obj);
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public Produto getPeloID (int id) 
	{
		try 
		{
			Produto obj = em.find(Produto.class, id);
			return obj;
		}
		catch (NoResultException e) 
		{
			return null;
		}
	}
	
	public List<Produto> getTodos()
	{
		try
		{
			Query query = em.createNamedQuery(CONSULTA_TODOS);
			List<Produto> lista = query.getResultList();
			return lista;
		}
		catch (NoResultException e)
		{
			return null;
		}
	}
	
	public List<Produto> getTodosOrdNome()
	{
		try
		{
			Query query = em.createNamedQuery(CONSULTA_ORDNOME);
			List<Produto> lista = query.getResultList();
			return lista;
		}
		catch (NoResultException e)
		{
			return null;
		}
	}
	
	public Produto getPorNome(String nome) 
	{

		try 
		{
			 Query query = em.createNamedQuery(CONSULTA_PORNOME);
			 query.setParameter("n", nome);
		     Produto obj = (Produto) query.getSingleResult();
			return obj;
		} 
		catch (NoResultException e) 
		{
			return null;
		}
	}
	
	@Override
	protected void finalize() throws Throwable 
	{
		super.finalize();

		if (factory != null)
			factory.close();

		if (em != null)
			em.close();
	}

}
